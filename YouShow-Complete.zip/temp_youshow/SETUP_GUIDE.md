# YouShow Setup & Deployment Guide

## Prerequisites
- Node.js 16+
- npm or yarn
- Supabase account

## Step 1: Environment Setup

Create `.env` file:
```
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_ANON_KEY=your-anon-key
```

Get from Supabase Dashboard:
1. Go to supabase.com
2. Create project
3. Settings → API
4. Copy URL and anon key

## Step 2: Install Dependencies
```bash
npm install
```

## Step 3: Database Setup

1. Go to Supabase SQL Editor
2. Copy DATABASE_MIGRATION.sql
3. Paste and run
4. Done!

## Step 4: Run Locally
```bash
npm run dev
```

Visit: http://localhost:5173

Test:
- [ ] Browse videos
- [ ] Search works
- [ ] Sound plays
- [ ] Shorts work
- [ ] Comments work

## Step 5: Build & Deploy

Build:
```bash
npm run build
```

Deploy to Vercel:
```bash
npm i -g vercel
vercel
```

Deploy to Netlify:
```bash
netlify deploy --prod --dir=dist
```

## Troubleshooting

No Sound?
- Check VideoPlayer unmuted
- Check volume not at 0

Videos Not Showing?
- Check RLS policies
- Verify visibility='public'

Build Error?
- rm -rf node_modules
- npm install
- npm run build

## Environment Variables

VITE_SUPABASE_URL - Project URL
VITE_SUPABASE_ANON_KEY - Public API key

All set! Start with: npm run dev

Happy Coding! 🎬
