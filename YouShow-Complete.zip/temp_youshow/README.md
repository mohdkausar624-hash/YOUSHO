# YouShow - Video Streaming Platform

Welcome to YouShow! A YouTube-like video streaming platform.

## Quick Start

1. Read PROJECT_DOCUMENTATION.md
2. Follow SETUP_GUIDE.md
3. Run DATABASE_MIGRATION.sql in Supabase
4. npm install && npm run dev

## Features
- Upload and watch videos with sound
- Public video browsing (no login required)
- TikTok-style shorts with auto-play
- Video search functionality
- User profiles and comments
- Full RLS security

## Tech Stack
- React 18 + TypeScript
- Vite
- Supabase
- Tailwind CSS

Status: ✅ Production Ready
Sound: ✅ Working
Public Access: ✅ Enabled

Happy Coding! 🎬
