/*
  YouShow Database Setup - Public Video Access
  
  Creates RLS policies enabling:
  - Unauthenticated users can view public videos
  - Anyone can search
  - Full public browsing
  - Secure access via RLS
*/

-- Public can view public videos
CREATE POLICY "Public can view public videos"
  ON videos FOR SELECT
  TO anon
  USING (visibility = 'public');

-- Public can view comments on public videos
CREATE POLICY "Public can view comments on public videos"
  ON comments FOR SELECT
  TO anon
  USING (
    EXISTS (
      SELECT 1 FROM videos
      WHERE videos.id = comments.video_id
      AND videos.visibility = 'public'
    )
  );

-- Public can view likes on public videos
CREATE POLICY "Public can view likes on public videos"
  ON likes FOR SELECT
  TO anon
  USING (
    EXISTS (
      SELECT 1 FROM videos
      WHERE videos.id = likes.video_id
      AND videos.visibility = 'public'
    )
  );

-- Public can view creator profiles
CREATE POLICY "Public can view creator profiles"
  ON profiles FOR SELECT
  TO anon
  USING (
    EXISTS (
      SELECT 1 FROM videos
      WHERE videos.user_id = profiles.id
      AND videos.visibility = 'public'
      LIMIT 1
    )
  );

-- Allow authenticated users to create comments
CREATE POLICY "Users can comment on public videos"
  ON comments FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM videos
      WHERE videos.id = video_id
      AND videos.visibility = 'public'
    )
  );

-- Allow authenticated users to like
CREATE POLICY "Users can like public videos"
  ON likes FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM videos
      WHERE videos.id = video_id
      AND videos.visibility = 'public'
    )
  );

-- Allow authenticated users to upload
CREATE POLICY "Users can upload videos"
  ON videos FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Enable RLS
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE videos ENABLE ROW LEVEL SECURITY;
ALTER TABLE comments ENABLE ROW LEVEL SECURITY;
ALTER TABLE likes ENABLE ROW LEVEL SECURITY;
ALTER TABLE subscriptions ENABLE ROW LEVEL SECURITY;
